package ramirez.erik.pkg2p321;

import persistence.InventarioDeModificaciones;
import model.TipoModificacion;
import model.ModificacionDeLorean;
import java.io.IOException;

public class RamirezErik2p321 {

    public static void main(String[] args) {
       try {
           InventarioDeModificaciones<ModificacionDeLorean> inv = new InventarioDeModificaciones<>();

            inv.agregar(new ModificacionDeLorean(1, "Flux Capacitor Mk1", "Doc Brown",TipoModificacion.TIEMPO));
            inv.agregar(new ModificacionDeLorean(2, "Mr. Fusion", "Doc Brown",TipoModificacion.ENERGIA));
            inv.agregar(new ModificacionDeLorean(3, "Hover Conversion", "Los Libios",TipoModificacion.CONVERSION_HOVER));
            inv.agregar(new ModificacionDeLorean(4, "Temporal Circuit V3", "Clara Clayton", TipoModificacion.TIEMPO)); 
            inv.agregar(new ModificacionDeLorean(5, "Shield Upgrade", "Marty McFly",TipoModificacion.SEGURIDAD));

            System.out.println("Modificaciones del DeLorean:");
            inv.paraCadaElemento(m -> System.out.println(m));

            System.out.println("\nModificaciones tipo TIEMPO:");
            inv.filtrar(m -> m.getTipo()== TipoModificacion.TIEMPO).forEach(m -> System.out.println(m));

            System.out.println("\nModificaciones que contienen 'hover':");
            inv.filtrar(m -> m.getNombre().contains("Hover")).forEach(m -> System.out.println(m));

            System.out.println("\nModificaciones ordenadas por ID:");
            inv.ordenar();
            inv.paraCadaElemento(p -> System.out.println(p));

            System.out.println("\nModificaciones ordenadas por nombre:");
            inv.ordenar((m1, m2) -> m1.getNombre().compareTo(m2.getNombre()));

            inv.guardarEnArchivo("src/data/modificaciones.dat");

            InventarioDeModificaciones<ModificacionDeLorean> cargado = new InventarioDeModificaciones<>();
            cargado.cargarDesdeArchivo("src/data/modificaciones.dat");
            
            System.out.println("\nModificaciones cargadas desde archivo binario:");
            cargado.paraCadaElemento(m -> System.out.println(m));

            inv.guardarEnCSV("src/data/modificaciones.csv");

            cargado.cargarDesdeCSV("src/data/modificaciones.csv", linea -> ModificacionDeLorean.fromCSV(linea));

            System.out.println("\nModificaciones cargadas desde archivo CSV:");
            cargado.paraCadaElemento(m -> System.out.println(m));

       } catch (IOException | ClassNotFoundException e) {
            System.err.println(e.getMessage());
        }
    }
}
