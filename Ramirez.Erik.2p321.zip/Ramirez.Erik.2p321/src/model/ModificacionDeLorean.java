package model;

import java.io.Serializable;
import config.CSVSerializable;

public class ModificacionDeLorean implements CSVSerializable<ModificacionDeLorean>, Comparable<ModificacionDeLorean>  {

    private static final long serialVersionUID = 1L;
    private int id;
    private String nombre;
    private String responsable;
    private TipoModificacion tipo;

    public ModificacionDeLorean(int id, String nombre, String responsable, TipoModificacion tipo) {
        this.id = id;
        this.nombre = nombre;
        this.responsable = responsable;
        this.tipo = tipo;
    }

    public String getNombre() {
        return nombre;
    }

    public TipoModificacion getTipo() {
        return tipo;
    }
    
    @Override
    public int compareTo(ModificacionDeLorean o) {
        return Integer.compare(id, o.id);
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + responsable + "," + tipo+"\n";
    }

    @Override
    public String toString() {
        return "ModificacionDeLorean{" + "id=" + id + ", nombre=" + nombre + ", responsable=" + responsable + ", tipo=" + tipo + '}';
    }
    
    public static ModificacionDeLorean fromCSV(String modificacionCSV){
       modificacionCSV =  modificacionCSV.substring(0, modificacionCSV.length());
       String[] datos = modificacionCSV.split(",");
       return new ModificacionDeLorean (Integer.parseInt(datos[0]), datos[1], datos[2], TipoModificacion.valueOf(datos[3]));
    }
}
