package model;

public enum TipoModificacion {
    
     MOTOR ,
     CONVERSION_HOVER,
     ENERGIA,
     TIEMPO,
     SEGURIDAD,
     EXPERIMENTAL 
    
}
