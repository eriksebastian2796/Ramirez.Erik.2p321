package config;

import java.io.Serializable;

public interface CSVSerializable<T> extends Serializable{

   String toCSV();

}
