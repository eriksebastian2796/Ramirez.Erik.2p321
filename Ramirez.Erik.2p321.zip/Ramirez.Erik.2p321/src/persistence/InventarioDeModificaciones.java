package persistence;

import model.ModificacionDeLorean;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Function;
import config.CSVSerializable;

public class InventarioDeModificaciones<T extends CSVSerializable<T> & Comparable<T>> implements Iterable<T> {

    List<T> items = new ArrayList<>();

    public void agregar(T obj) {
        Objects.requireNonNull(obj, "La modificacion no puede ser null");
        items.add(obj);
    }

    public void eliminar(int indice) {
        validarIndice(indice);
        items.remove(indice);
    }

    public T obtenerPorIndice(int indice) {
        validarIndice(indice);
        return items.get(indice);
    }

    private void validarIndice(int indice) {
        if (indice < 0 || indice >= items.size()) {
            throw new IndexOutOfBoundsException("Índice fuera de rango");
        }
    }

    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> listaFiltrada = new ArrayList<>();

        for (T item : items) {
            if (criterio.test(item)) {
                listaFiltrada.add(item);
            }
        }
        return listaFiltrada;
    }

    public void ordenar() {
        Collections.sort(items);
    }

    public void ordenar(Comparator<? super T> c) {
        items.sort(c);
    }


    @Override
    public Iterator<T> iterator() {
        return new ArrayList<>(items).iterator();
    }

    public Iterator<T> iterator(Comparator<? super T> comp) {
        return new ArrayList<>(items).iterator();
    }

    public void paraCadaElemento(Consumer<T> cons) {
        for (T elemento : items) {
            cons.accept(elemento);
        }
    }

    public void guardarEnCSV(String path) throws IOException {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {
            escritor.write("id,nombre,responsable,tipo\n");
            for (T item : items) {
                escritor.write(item.toCSV());
            }
        }
    }

    public void cargarDesdeCSV(String path, Function<String, T> function) throws IOException {
        try (BufferedReader lector = new BufferedReader(new FileReader(path))) {
            String linea;
            lector.readLine(); // Saltar cabecera
            while ((linea = lector.readLine()) != null) {
                if (!linea.trim().isEmpty()) {
                    T objeto = function.apply(linea);
                    items.add(objeto);
                }
            }
        }
    }
    
    public void guardarEnArchivo(String path) throws IOException {
        try (ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(path))) {
            serializador.writeObject(this.items);
        }
    }
    
    public List<ModificacionDeLorean> cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException{
        List<ModificacionDeLorean> toReturn = null;
        try (ObjectInputStream deserializador = new ObjectInputStream(new FileInputStream(path))) {
            toReturn = (List<ModificacionDeLorean>) deserializador.readObject();
        } 
        return toReturn;
    }
}
